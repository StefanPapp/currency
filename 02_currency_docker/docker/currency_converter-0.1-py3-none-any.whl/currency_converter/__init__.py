"""
currencty
"""

import logging

__version__ = "0.0.1"

LOGGER = logging.getLogger("core")
